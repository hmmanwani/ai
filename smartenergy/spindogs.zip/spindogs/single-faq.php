<?php
wp_redirect(get_post_type_archive_link('faq'));
exit;
